<!DOCTYPE html>
<html lang="en">
<head>
<title>Payroll System | SegWorks Technologies Corporation</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="http://fonts.googleapis.com/css?family=Quicksand:400,300,700" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/login.css" />

<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="../assets/js/html5shiv.js"></script>
    <![endif]-->

</head>

<body>
<header>

</header>
<div id="content">
	<div class="container">
			<!--<h1><a href="#">SegWorks</a></h1>-->
		<div id="login-page">
		<form name="login" method="post" action="#">
			<p>
				<label>Username:</label>
				<input type="text" name="username" />
			</p>
			<label>Password:</label>
			<input type="password" name="password" />
			<p>
				<input type="submit" value="Submit" />
			</p>
		</form>
	</div>
	</div>
</div>
<footer>

</footer>
</body>
</html>
